# Threat model

Author: Daniel Scribe — github.com/dmscribe

Sanctum is a ciphertext messenger with device-held human keys, server-held
servant keys for network voices, and exact-lookup contacts on a desk UI. This
document states the current trust boundaries, protections, and residual risk.

## System properties

- Mailbox packets use ECIES over P-256 with HKDF-SHA-256 and AES-GCM.
- The server stores ciphertext fields, nonces, ephemeral public keys, pair ids,
  timestamps, graph edges, public identity material, and moderation state.
- Human device secrets live in the browser vault backed by IndexedDB.
- Network-servant private keys live in `ghost_vaults` so servants can decrypt
  inbound lines and sign replies in their own key domain.
- Identity backup wrap v3 uses HKDF-SHA-256 and AES-256-GCM. Older backup files
  still open for compatibility.

## In-scope threats and present controls

### Malicious or compromised server swapping a device key

Risk: a server can try to replace a published P-256 device JWK and sit in the
middle.

Controls:
- `publishKeys` verifies that the armored public key fingerprint matches the
  submitted fingerprint.
- `publishKeys` verifies that the Ed25519 binding canonically covers the exact
  seat id and P-256 JWK being published.
- The client verifies the binding before encrypting and warns on verified
  fingerprint changes.

Residual risk: a person who never compares fingerprints can still trust a bad
key presented by an untrusted server.

### Server reading or altering human mailbox plaintext

Risk: the mailbox service sees transport metadata and stored packet fields.

Controls:
- Human message bodies are encrypted on device with per-message ephemeral ECIES.
- The mailbox stores ciphertext, nonce, ephemeral public key, media metadata,
  expiry, sender/recipient ids, and timestamps.
- Byte caps are enforced against decoded ciphertext size, not base64 string
  length.
- Human authorship is checked after decrypt through the inner signature path.

Residual risk: the server still learns who talked to whom, when, and how large a
packet was.

### Servant impersonation or servant-message disclosure

Risk: compromising the servant vault lets an attacker read or forge network
voice traffic for those servant ids.

Controls:
- Servant keys live in `ghost_vaults`, separate from human browser vaults.
- Server decrypt for servants is keyed by recipient id and no-ops for human
  recipients.
- No crossover path was found that copies a human device key into
  `ghost_vaults`.

Residual risk: servant compromise affects network voices only. It does not
expose conversations between two human seats.

### Device theft or unlocked browser origin compromise

Risk: an attacker with the seat's device key and an unlocked browser origin can
read future mail for that seat until rotation.

Controls:
- Human secrets stay local to the browser vault.
- Raw key export is behind an explicit typed `EXPORT` or handle confirmation.
- Backup export uses v3 AES-GCM by default.

Residual risk: Sanctum does not ship a session ratchet. The long-term device key
still anchors that seat until rotated.

### Backup file theft

Risk: a copied backup file can be attacked offline.

Controls:
- New backup files use HKDF-SHA-256 with a random salt and AES-256-GCM with a
  random 12-byte nonce.
- Tampered v3 tags fail closed.
- Older files still open so operators are not stranded.

Residual risk: legacy v1/v2 files remain only as import formats. Weak
passphrases on old exports stay weak until the operator makes a fresh v3 export.

### GPS misuse or false location

Risk: location can be spoofed and can reveal coarse region when enabled.

Controls:
- GPS is opt-in.
- The device uses raw coordinates only to choose the nearest regional servant.
- The server stores coarse region with consent rather than raw coordinates.

Residual risk: a mocked device can still claim a false region and meet a
different regional servant.

## Out-of-scope properties of this tag

- No session ratchet or other post-compromise secrecy layer.
- No group-chat protocol.
- No screenshot prevention.
- No protection against plaintext copies a recipient chooses to save after
  decrypt.
- No guarantee that a person will verify fingerprints over a second channel.

## Servant keys

Network servants (Ryder, Charlie, regional ghosts) are processes, not people.
`ghost_vaults` holds their P-256 device key and Ed25519 signing key server-side
so a servant can decrypt an inbound line and sign a mirrored reply without a
human operating a browser session for it. That is a deliberate, separate key
domain:

- `loadGhostVault(userId)` only returns a row when `userId` is a servant id
  seeded into `ghost_vaults`. A real operator id has no row there.
- `mirrorIfServant` looks the row up by recipient id and returns `null`
  immediately if no servant vault exists for that id, so it never decrypts on
  behalf of a human recipient.
- `ghostDeliverText` and `befriendServant` read or link that same table; neither
  writes a human device private JWK or secret key into it.
- A human device secret is generated in the browser (`src/lib/sanctum/vault.ts`)
  and leaves the browser only when the operator explicitly exports a wrapped
  backup file.

Traced call paths (server): `mailbox.ts` sendMessage -> `mirrorIfServant` ->
`loadGhostVault(recipientId)` -> decrypt with the servant's own key ->
re-encrypt for the human's public key. Traced call paths (client):
`ChatThread.tsx` decrypts with `activeSeat.device.privateJwk` from the local
vault for both human and servant peers.

Compromising `ghost_vaults` lets an attacker impersonate or decrypt for network
servants. It does not expose any operator device key, and it does not let a
servant read a conversation between two human operators.

## Operator ritual

Compare fingerprints in person, on a call you already trust, or over another
channel you already trust. The server can present a bad key; the ritual is what
catches the swap.
