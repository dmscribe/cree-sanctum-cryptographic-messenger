# Cree Sanctum Cryptographic Messaging

Windowed cryptographic messenger with human contacts on a desk OS, a
ciphertext mailbox, device-bound identity, and an optional throwaway seat
restored by a sixteen-word phrase.

Author: **Daniel Scribe** (Pimicikamak Cree Nation, Turtle Island) —
[github.com/dmscribe](https://github.com/dmscribe) · [x.com/danRydr](https://x.com/danRydr)

A story is only a story if the right person hears it.

## What Sanctum is

- Sealed text and walkie-talkie voice between chosen contacts.
- Device-bound identity: Ed25519 binding over a P-256 device key.
- Ciphertext mailbox: the server stores ciphertext fields and routing
  metadata, not message plaintext.
- Discover radar that can be shut off with Stealth.
- Network servants in a separate key domain from human seats.
- Dual-licensed source code with MIT and Apache 2.0 licence texts in the repo.

## Local run

1. `npm ci`
2. Copy `.env.example` to `.env`
3. Fill `BETTER_AUTH_SECRET` with a long random development secret
4. Leave `DATABASE_URL` empty to use local PGLite, or point it at Postgres/Neon
5. Run `npm run dev` or `sh ./startup.sh`
6. Open `http://127.0.0.1:8080`

## Security references

- Threat model: [docs/THREAT_MODEL.md](docs/THREAT_MODEL.md)
- Crypto audit: [docs/CRYPTO_AUDIT.md](docs/CRYPTO_AUDIT.md)
- Project map: [docs/PROJECT_MAP.md](docs/PROJECT_MAP.md)

## Licences

This program is dual-licensed. You may use it under the MIT License or the
Apache License, Version 2.0, at your option. See `LICENSE-MIT`, `LICENSE`,
`public/LICENSE-MIT.txt`, and `public/LICENSE-APACHE.txt`.

Copyright (c) 2026 Daniel Scribe.
